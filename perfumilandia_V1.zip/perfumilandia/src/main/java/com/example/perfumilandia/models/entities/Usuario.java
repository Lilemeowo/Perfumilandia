package com.example.perfumilandia.models.entities;


@Entity
@Data
@Table(name="usuario")

public class Usuario {

    @id
    @GeneratedValue(Strategy=GenerationType.IDENTITY)
    private int id_usuario;

    @Column(nullable=false)
    private String nombre_completo;

    @Column(nullable = false, unique= true)
    private String email;

    @Column(nullable=false)
    private String password;

    @Column(nullable=false)
    private boolean activo;

    @ManyToOne
    @JoinColumn(name = "id_rol",nullable=false)
    private Rol rol 
}
