package com.example.perfumilandia.models.entities;

public class Cliente {

}
