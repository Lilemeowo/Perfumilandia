package com.example.perfumilandia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfumilandiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfumilandiaApplication.class, args);
	}

}
