package com.example.perfumilandia.models.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;


@Entity
@Data
@Table(name="Rol")


public class Rol {
@id
@GeneratedValues(Strategy=GenerationType.IDENTITY)
private int id_rol;

@Column(nullable = False, Length = 50 )
private String nombre_rol;

@Column(Length=255)
private String descripcion ;



}
