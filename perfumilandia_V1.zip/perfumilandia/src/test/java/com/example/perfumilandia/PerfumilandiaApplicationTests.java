package com.example.perfumilandia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PerfumilandiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
